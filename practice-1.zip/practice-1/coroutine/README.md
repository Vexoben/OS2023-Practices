# coroutine

## Test Kit Development
- [x] co_start
- [x] co_getid
- [x] co_getret
- [x] co_yield
- [ ] co_yield(nested)
- [x] co_waitall
- [x] co_wait
- [x] co_status

* Note: Actually, `co_wait` and `co_waitall` is unnecessary in 1-to-N model. (One thread to several coroutines) Think why.
